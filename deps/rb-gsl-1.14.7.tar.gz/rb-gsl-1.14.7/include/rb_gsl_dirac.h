#ifndef ___RB_GSL_DIRAC_H___
#define ___RB_GSL_DIRAC_H___

#include "rb_gsl.h"
#include "rb_gsl_common.h"
#include "rb_gsl_complex.h"
#include "rb_gsl_array.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#endif
