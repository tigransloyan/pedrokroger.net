require('rb_gsl')
require('gsl/oper.rb')
